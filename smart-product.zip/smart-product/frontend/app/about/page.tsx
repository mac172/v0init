import ProductComparison from '../product/Demo.tsx'

export default function About() {
  return (
    <div>
    <ProductComparison />
    </div>
  )
}
